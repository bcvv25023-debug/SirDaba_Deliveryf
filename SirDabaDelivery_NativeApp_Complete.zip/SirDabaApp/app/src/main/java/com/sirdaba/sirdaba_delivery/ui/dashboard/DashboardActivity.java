package com.sirdaba.sirdaba_delivery.ui.dashboard;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.google.firebase.messaging.FirebaseMessaging;
import com.onesignal.OneSignal;
import com.sirdaba.sirdaba_delivery.R;
import com.sirdaba.sirdaba_delivery.api.SirDabaRepository;
import com.sirdaba.sirdaba_delivery.databinding.ActivityDashboardBinding;
import com.sirdaba.sirdaba_delivery.ui.login.LoginActivity;
import com.sirdaba.sirdaba_delivery.ui.notifications.NotificationsFragment;
import com.sirdaba.sirdaba_delivery.ui.orders.OrdersFragment;
import com.sirdaba.sirdaba_delivery.ui.profile.ProfileFragment;
import com.sirdaba.sirdaba_delivery.utils.TokenManager;

public class DashboardActivity extends AppCompatActivity {

    private ActivityDashboardBinding binding;
    private SirDabaRepository repo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDashboardBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);
        repo = new SirDabaRepository(this);

        // التحقق من تسجيل الدخول
        if (!TokenManager.isLoggedIn(this)) {
            logout();
            return;
        }

        setupBottomNav();

        // عرض شاشة الطلبات افتراضياً
        if (savedInstanceState == null) {
            showFragment(new OrdersFragment());
        }

        // تحديث FCM Token عند فتح التطبيق
        refreshFcmToken();
    }

    private void setupBottomNav() {
        binding.bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_orders) {
                showFragment(new OrdersFragment());
                return true;
            } else if (id == R.id.nav_notifications) {
                showFragment(new NotificationsFragment());
                return true;
            } else if (id == R.id.nav_profile) {
                showFragment(new ProfileFragment());
                return true;
            }
            return false;
        });
    }

    private void showFragment(Fragment fragment) {
        getSupportFragmentManager()
            .beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .commit();
    }

    private void refreshFcmToken() {
        FirebaseMessaging.getInstance().getToken()
            .addOnSuccessListener(token -> {
                if (token != null && !token.isEmpty()) {
                    repo.registerFcmToken(token, new SirDabaRepository.Callback<>() {
                        @Override public void onSuccess(Object data) {}
                        @Override public void onError(String message) {}
                    });
                }
            });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0, R.id.nav_profile, 0, R.string.logout)
            .setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.nav_profile) {
            performLogout();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void performLogout() {
        repo.logout(new SirDabaRepository.Callback<>() {
            @Override public void onSuccess(Object data) {
                runOnUiThread(() -> logout());
            }
            @Override public void onError(String message) {
                runOnUiThread(() -> logout());
            }
        });
    }

    private void logout() {
        // إلغاء ربط OneSignal عند تسجيل الخروج
        OneSignal.logout();
        TokenManager.clearAll(this);
        startActivity(new Intent(this, LoginActivity.class));
        finish();
    }
}
