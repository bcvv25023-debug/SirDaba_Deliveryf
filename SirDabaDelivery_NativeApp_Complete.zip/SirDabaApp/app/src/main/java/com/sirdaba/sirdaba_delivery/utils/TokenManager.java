package com.sirdaba.sirdaba_delivery.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class TokenManager {

    private static final String PREFS = "sirdaba_auth";
    private static final String KEY_JWT = "jwt_token";
    private static final String KEY_NONCE = "nonce";
    private static final String KEY_USER_ID = "user_id";
    private static final String KEY_USER_NAME = "user_name";
    private static final String KEY_USER_EMAIL = "user_email";
    private static final String KEY_USER_TYPE = "user_type";
    private static final String KEY_USER_PHONE = "user_phone";
    private static final String KEY_USER_CITY = "user_city";
    private static final String KEY_WALLET = "wallet_balance";
    private static final String KEY_IS_APPROVED = "is_approved";
    private static final String KEY_LAST_CHECK = "last_live_check";

    private static SharedPreferences getPrefs(Context ctx) {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    // ── JWT ───────────────────────────────────────────────────────
    public static void saveJwtToken(Context ctx, String token) {
        getPrefs(ctx).edit().putString(KEY_JWT, token).apply();
    }

    public static String getJwtToken(Context ctx) {
        return getPrefs(ctx).getString(KEY_JWT, "");
    }

    public static boolean hasJwtToken(Context ctx) {
        String t = getJwtToken(ctx);
        return t != null && !t.isEmpty();
    }

    // ── Nonce ─────────────────────────────────────────────────────
    public static void saveNonce(Context ctx, String nonce) {
        getPrefs(ctx).edit().putString(KEY_NONCE, nonce).apply();
    }

    public static String getNonce(Context ctx) {
        return getPrefs(ctx).getString(KEY_NONCE, "");
    }

    // ── User Profile ──────────────────────────────────────────────
    public static void saveUser(Context ctx, int id, String name, String email,
                                String type, String phone, String city,
                                double wallet, boolean approved, String nonce) {
        getPrefs(ctx).edit()
            .putInt(KEY_USER_ID, id)
            .putString(KEY_USER_NAME, name)
            .putString(KEY_USER_EMAIL, email)
            .putString(KEY_USER_TYPE, type)
            .putString(KEY_USER_PHONE, phone)
            .putString(KEY_USER_CITY, city)
            .putFloat(KEY_WALLET, (float) wallet)
            .putBoolean(KEY_IS_APPROVED, approved)
            .putString(KEY_NONCE, nonce)
            .apply();
    }

    public static int getUserId(Context ctx) {
        return getPrefs(ctx).getInt(KEY_USER_ID, 0);
    }

    public static String getUserName(Context ctx) {
        return getPrefs(ctx).getString(KEY_USER_NAME, "");
    }

    public static String getUserEmail(Context ctx) {
        return getPrefs(ctx).getString(KEY_USER_EMAIL, "");
    }

    public static String getUserType(Context ctx) {
        return getPrefs(ctx).getString(KEY_USER_TYPE, "distributor");
    }

    public static String getUserPhone(Context ctx) {
        return getPrefs(ctx).getString(KEY_USER_PHONE, "");
    }

    public static String getUserCity(Context ctx) {
        return getPrefs(ctx).getString(KEY_USER_CITY, "");
    }

    public static double getWalletBalance(Context ctx) {
        return getPrefs(ctx).getFloat(KEY_WALLET, 0f);
    }

    public static boolean isApproved(Context ctx) {
        return getPrefs(ctx).getBoolean(KEY_IS_APPROVED, false);
    }

    public static boolean isLoggedIn(Context ctx) {
        return getUserId(ctx) > 0 && hasJwtToken(ctx);
    }

    // ── Live Polling ──────────────────────────────────────────────
    public static void saveLastCheck(Context ctx, long timestamp) {
        getPrefs(ctx).edit().putLong(KEY_LAST_CHECK, timestamp).apply();
    }

    public static long getLastCheck(Context ctx) {
        return getPrefs(ctx).getLong(KEY_LAST_CHECK, 0L);
    }

    // ── Logout ────────────────────────────────────────────────────
    public static void clearAll(Context ctx) {
        getPrefs(ctx).edit().clear().apply();
    }
}
