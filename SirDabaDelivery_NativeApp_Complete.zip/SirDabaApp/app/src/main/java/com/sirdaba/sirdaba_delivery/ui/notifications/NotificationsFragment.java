package com.sirdaba.sirdaba_delivery.ui.notifications;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.sirdaba.sirdaba_delivery.R;

public class NotificationsFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        TextView tv = new TextView(requireContext());
        tv.setText(R.string.no_notifications);
        tv.setPadding(48, 48, 48, 48);
        tv.setTextSize(16f);
        tv.setGravity(android.view.Gravity.CENTER);
        return tv;
    }
}
