package com.sirdaba.sirdaba_delivery.api;

import com.sirdaba.sirdaba_delivery.models.*;
import retrofit2.Call;
import retrofit2.http.*;
import java.util.Map;

public interface ApiService {

    // ── Bootstrap ──────────────────────────────────────────────────
    @GET("sirdaba/v1/mobile/bootstrap")
    Call<BootstrapResponse> getBootstrap();

    // ── Auth (JWT) ─────────────────────────────────────────────────
    @FormUrlEncoded
    @POST("jwt-auth/v1/token")
    Call<JwtResponse> getJwtToken(
        @Field("username") String username,
        @Field("password") String password
    );

    @POST("jwt-auth/v1/token/validate")
    Call<BaseResponse> validateJwtToken();

    @FormUrlEncoded
    @POST("sirdaba/v1/mobile/set-app-token")
    Call<BaseResponse> setAppTokenCookie(@Field("token") String token);

    // ── Current User ───────────────────────────────────────────────
    @GET("sirdaba/v1/mobile/me")
    Call<UserResponse> getCurrentUser();

    // ── Device Token (Push) ────────────────────────────────────────
    @FormUrlEncoded
    @POST("sirdaba/v1/mobile/device-token")
    Call<BaseResponse> registerDeviceToken(
        @Field("token") String fcmToken,
        @Field("platform") String platform,
        @Field("app_version") String appVersion
    );

    @DELETE("sirdaba/v1/mobile/device-token")
    Call<BaseResponse> unregisterDeviceToken();

    // ── Live Updates ───────────────────────────────────────────────
    @GET("sirdaba/v1/live/updates")
    Call<LiveUpdatesResponse> getLiveUpdates(
        @Query("last_check") long lastCheck,
        @Query("user_type") String userType
    );

    // ── AJAX: Distributor Login ────────────────────────────────────
    @FormUrlEncoded
    @POST(".")
    Call<LoginResponse> distLogin(
        @Field("action") String action,
        @Field("email") String email,
        @Field("password") String password,
        @Field("sd_nonce") String nonce
    );

    // ── AJAX: Distributor Logout ───────────────────────────────────
    @FormUrlEncoded
    @POST(".")
    Call<BaseResponse> distLogout(
        @Field("action") String action,
        @Field("sd_nonce") String nonce
    );

    // ── AJAX: Get Orders ───────────────────────────────────────────
    @FormUrlEncoded
    @POST(".")
    Call<OrdersResponse> getOrders(
        @Field("action") String action,
        @Field("sd_nonce") String nonce,
        @Field("status") String status
    );

    // ── AJAX: Accept Order ─────────────────────────────────────────
    @FormUrlEncoded
    @POST(".")
    Call<BaseResponse> acceptOrder(
        @Field("action") String action,
        @Field("order_id") int orderId,
        @Field("sd_nonce") String nonce
    );

    // ── AJAX: Verify Delivery OTP ──────────────────────────────────
    @FormUrlEncoded
    @POST(".")
    Call<BaseResponse> verifyDeliveryOtp(
        @Field("action") String action,
        @Field("order_id") int orderId,
        @Field("otp") String otp,
        @Field("sd_nonce") String nonce
    );

    // ── AJAX: Update Driver Location ───────────────────────────────
    @FormUrlEncoded
    @POST(".")
    Call<BaseResponse> updateLocation(
        @Field("action") String action,
        @Field("order_id") int orderId,
        @Field("lat") double lat,
        @Field("lng") double lng,
        @Field("sd_nonce") String nonce
    );

    // ── AJAX: Wallet Request ───────────────────────────────────────
    @FormUrlEncoded
    @POST(".")
    Call<BaseResponse> walletRequest(
        @Field("action") String action,
        @Field("amount") double amount,
        @Field("method") String method,
        @Field("sd_nonce") String nonce
    );

    // ── AJAX: Get Notifications ────────────────────────────────────
    @FormUrlEncoded
    @POST(".")
    Call<NotificationsResponse> getNotifications(
        @Field("action") String action,
        @Field("sd_nonce") String nonce
    );

    // ── AJAX: Mark Notification Read ──────────────────────────────
    @FormUrlEncoded
    @POST(".")
    Call<BaseResponse> markNotificationRead(
        @Field("action") String action,
        @Field("notification_id") int notifId,
        @Field("sd_nonce") String nonce
    );

    // ── AJAX: Submit Cancel Request ───────────────────────────────
    @FormUrlEncoded
    @POST(".")
    Call<BaseResponse> submitCancelRequest(
        @Field("action") String action,
        @Field("order_id") int orderId,
        @Field("reason") String reason,
        @Field("sd_nonce") String nonce
    );

    // ── Track Order ────────────────────────────────────────────────
    @GET("sirdaba/v1/track-order")
    Call<TrackOrderResponse> trackOrder(@Query("order_code") String orderCode);
}
